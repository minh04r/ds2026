import socket
import os


filename = input()
only_filename = os.path.basename(filename)
print(only_filename)
file = open(filename, "rb")
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('0.0.0.0',9999))

client.send(only_filename.encode("utf-8"))
client.send(b'\0')

data = file.read(1024) # Cắn một miếng 1024 bytes
while data:
    client.send(data) # Nhai và nuốt
    data = file.read(1024) # Cắn miếng tiếp theo
file.close()
print("Đã gửi xong, mệt vãi nồi!")

