import socket
import random

def GenerateRandom():
    hash = random.getrandbits(128)
    print("hash value: %032x" % hash)
    return str(hash)

def ReceiveFileName(client : socket):
    filenameByte = b''
    while True:
        byte = client.recv(1)
        if (byte == b'\0'):
            break
        filenameByte += byte
    filename = filenameByte.decode('utf-8')
    print("getted filename: " + filename)
    return  GenerateRandom() + ' ' + filename

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(('0.0.0.0', 9999)) 
server.listen()

while (True):
    print("good")
    client, addr = server.accept()
    print("accept")
   
    filename = ReceiveFileName(client)
    file = open(filename, "wb")
    while True:
        data = client.recv(1024) 
        if not data:
            break 
        file.write(data)
    file.close()



